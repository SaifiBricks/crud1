﻿//using Forms_CRUD_.Models;

//namespace Forms_CRUD_.ViewModels
//{
//    public class HomeViewModel
//    {
//        public int Id { get; set; }
//        public string PhotoImage { get; set; }
//    }
//}
